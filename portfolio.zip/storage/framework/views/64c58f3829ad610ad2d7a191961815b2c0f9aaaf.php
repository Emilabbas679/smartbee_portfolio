<head>
<meta charset="utf-8">
<title> <?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('app_name')); ?></title>
<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
<link media="screen" href="<?php echo e(asset('/site/css/style.css')); ?>" type="text/css" rel="stylesheet" />
<link media="screen" href="<?php echo e(asset('/site/css/responsive.css')); ?>" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="<?php echo e(asset('/site/js/jquery.js')); ?>"></script>

    <?php echo $__env->yieldContent('css'); ?>
</head>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/site/parts/head.blade.php ENDPATH**/ ?>