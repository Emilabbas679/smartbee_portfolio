<?php $__env->startSection('title',__('titles.categories')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold text-primary"> <?php echo e(__('titles.categories')); ?></h6>
            <a href="<?php echo e(route('project-category.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-plus text-white-50"></i> <?php echo e(__('admin.add')); ?></a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php echo $__env->make('admin.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(__('admin.title')); ?></th>
                        <th><?php echo e(__('admin.slug')); ?></th>
                        <th><?php echo e(__('admin.status')); ?></th>
                        <th><?php echo e(__('admin.created')); ?></th>
                        <th><?php echo e(__('admin.updated')); ?></th>
                        <th><?php echo e(__('admin.operations')); ?></th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(__('admin.title')); ?></th>
                        <th><?php echo e(__('admin.slug')); ?></th>
                        <th><?php echo e(__('admin.status')); ?></th>
                        <th><?php echo e(__('admin.created')); ?></th>
                        <th><?php echo e(__('admin.updated')); ?></th>
                        <th><?php echo e(__('admin.operations')); ?></th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->slug); ?></td>
                            <td><?php echo e(__('admin.status_id_'.$item->status_id)); ?></td>
                            <td><?php echo e(date('d.m.Y', strtotime($item->created_at))); ?></td>
                            <td><?php echo e(date('d.m.Y', strtotime($item->updated_at))); ?></td>
                            <td>

                                <form id="delete-form" action="<?php echo e(route('project-category.destroy', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a class="btn btn-primary btn-circle btn-sm" href="<?php echo e(route('project-category.edit', $item->id)); ?>">
                                        <i class="far fa-edit"></i>
                                    </a>
                                    <button class="btn btn-danger btn-circle btn-sm"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/admin/project-categories/index.blade.php ENDPATH**/ ?>