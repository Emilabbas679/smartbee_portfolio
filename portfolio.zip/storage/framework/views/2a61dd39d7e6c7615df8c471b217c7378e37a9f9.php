<?php $__env->startSection('title', __('titles.add').' | '.__('titles.projects')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('admin.add')); ?></h6>
        </div>
        <div class="card-body">
            <div class="col-md-6 offset-md-3">
                <form class="user form" method="POST" action="<?php echo e(route('project-category.store')); ?>" enctype="multipart/form-data">
                    <?php echo $__env->make('admin.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                    <?php echo csrf_field(); ?>

                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <?php $__currentLoopData = Config::get('global.langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(($locale['code'] == 'en') ? 'active': ''); ?>" id="pills-tab-<?php echo e($locale['code']); ?>"
                                   data-toggle="pill" href="#pills-<?php echo e($locale['code']); ?>" role="tab"
                                   aria-controls="pills-<?php echo e($locale['code']); ?>" aria-selected="true"><?php echo e($locale['name']); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content pt-2 pl-1" id="pills-tabContent">
                        <?php $__currentLoopData = Config::get('global.langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade show <?php echo e(($locale['code'] == 'en') ? 'active': ''); ?>" id="pills-<?php echo e($locale['code']); ?>"
                                 role="tabpanel" aria-labelledby="pills-tab-<?php echo e($locale['code']); ?>">

                                <div class="form-group row">
                                    <div class="col-md-2">
                                        <label for="title"><?php echo e(__('admin.title')); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <input id="title_<?php echo e($locale['code']); ?>" type="text" class="form-control <?php $__errorArgs = ['title.'.$locale['code']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="title[<?php echo e($locale['code']); ?>]" value="<?php echo e(old('title.'.$locale['code'])); ?>"
                                               placeholder="<?php echo e(__('admin.title')); ?> (<?php echo e($locale['code']); ?>)" >
                                        <?php $__errorArgs = ['title.'.$locale['code']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-2">
                                        <label for="title"><?php echo e(__('admin.description')); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <textarea  placeholder="<?php echo e(__('admin.description')); ?> (<?php echo e($locale['code']); ?>)" id="description_<?php echo e($locale['code']); ?>" rows="5" class="form-control <?php $__errorArgs = ['description.'.$locale['code']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description[<?php echo e($locale['code']); ?>]"><?php echo e(old('description.'.$locale['code'])); ?></textarea>

                                        <?php $__errorArgs = ['description.'.$locale['code']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="status_id"><?php echo e(__('admin.status')); ?></label>
                        </div>
                        <div class="col-md-10">
                            <select name="status_id" id="status_id" class="form-control">
                                <option value="1" <?php echo e(selected(old('status_id'),'1')); ?>><?php echo e(__('admin.status_id_1')); ?></option>
                                <option value="0" <?php echo e(selected(old('status_id'),'0')); ?>><?php echo e(__('admin.status_id_0')); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="status_id"><?php echo e(__('admin.category')); ?></label>
                        </div>
                        <div class="col-md-10">
                            <select name="category_id" id="category_id" class="form-control">
                                <option value="0" <?php echo e(selected(old('category_id'),'0')); ?>><?php echo e(__('admin.not_selected')); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php echo e(selected(old('category_id'),$cat->id)); ?>><?php echo e($cat->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="domain"><?php echo e(__('admin.domain')); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input id="domain" type="text" class="form-control <?php $__errorArgs = ['domain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="domain" value="<?php echo e(old('domain')); ?>"
                                   placeholder="<?php echo e(__('admin.domain')); ?>" >
                            <?php $__errorArgs = ['domain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="background"><?php echo e(__('admin.background')); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input id="background" type="text" class="form-control <?php $__errorArgs = ['background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="background" value="<?php echo e(old('background')); ?>"
                                   placeholder="<?php echo e(__('admin.background')); ?>" >
                            <?php $__errorArgs = ['background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="delivery_date"><?php echo e(__('admin.delivery_date')); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input id="delivery_date" type="date" class="form-control <?php $__errorArgs = ['delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="delivery_date" value="<?php echo e(old('delivery_date')); ?>"
                                   placeholder="<?php echo e(__('admin.delivery_date')); ?>" >
                            <?php $__errorArgs = ['delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>



                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="image_index"><?php echo e(__('admin.image_index_project')); ?></label>
                        </div>
                        <div class="col-md-10">

                            <input class="m-image" type="hidden" name="image_index">
                            <div id="image_index" class="fallback dropzone"></div>



                            <?php $__errorArgs = ['image_index'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="image_main"><?php echo e(__('admin.image_main_project')); ?></label>
                        </div>
                        <div class="col-md-10">

                            <input class="m-image2" type="hidden" name="image_main">
                            <div id="image_main" class="fallback dropzone"></div>

                            <?php $__errorArgs = ['image_main'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="gallery"><?php echo e(__('admin.gallery')); ?></label>
                        </div>
                        <div class="col-md-10">

                            <input class="m-image3" type="hidden" name="gallery[]">
                            <div id="gallery" class="fallback dropzone"></div>

                            <?php $__errorArgs = ['gallery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <input class="uid" name="uid" type="hidden" value="<?=rand(9999, 9999999); ?>">

                    <div class="d-flex justify-content-center">

                    <button type="submit" class="btn btn-primary " id="submit_btn">
                        <?php echo e(__('admin.save')); ?>

                    </button>
                    </div>
                </form>


            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/back/vendor/dropzone/dist/dropzone.css')); ?>" rel="stylesheet" type="text/css"/>

    <?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('/back/vendor/dropzone/dist/dropzone.js')); ?>"></script>

    <script>
        var galleryitems = [];

        Dropzone.autoDiscover = false;

        var image_index = new Dropzone("#image_index", {

            url: "<?php echo e(route('file.store')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            paramName: "image_index",
            timeout: 180000,
            addRemoveLinks: true,
            hiddenInputContainer: ".form",
            maxFiles: 1,
            dictRemoveFile: "Şəkli sil",
            dictCancelUpload: "Yükləməni dayandır",
            dictDefaultMessage: "Şəkli sürüşdürüb buraxın və ya Seçin",
            dictMaxFilesExceeded: "Əlavə şəkil yükləyə bilməzsiniz",

            removedfile: function(file) {
                file.previewElement.remove();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    },
                    type: 'POST',
                    url: '<?php echo e(route('files.delete')); ?>',
                    data: {'add' : 'addform', 'uid' : $('.uid').val(), 'm_image' : $('.m-image').val()}
                });
                $('.m-image').val('');
            },

            success: function(response){
                $('.m-image').val(response.xhr.response)
            },

        });


        image_index.on('maxfilesreached', function() {
            image_index.removeEventListeners();
        });
        image_index.on('sending', function(file, xhr, formData){
            formData.append('uid', $('.uid').val());
        });
        image_index.on('removedfile', function (file) {
            image_index.setupEventListeners();
        });



        var image_main = new Dropzone("#image_main", {

            url: "<?php echo e(route('file.store')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            paramName: "image_main",
            timeout: 180000,
            addRemoveLinks: true,
            hiddenInputContainer: ".form",
            maxFiles: 1,
            dictRemoveFile: "Şəkli sil",
            dictCancelUpload: "Yükləməni dayandır",
            dictDefaultMessage: "Şəkli sürüşdürüb buraxın və ya Seçin",
            dictMaxFilesExceeded: "Əlavə şəkil yükləyə bilməzsiniz",

            removedfile: function(file) {
                file.previewElement.remove();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    },
                    type: 'POST',
                    url: '<?php echo e(route('files.delete')); ?>',
                    data: {'add' : 'addform', 'uid' : $('.uid').val(), 'm_image2' : $('.m-image2').val()}
                });
                $('.m-image2').val('');
            },

            success: function(response){
                $('.m-image2').val(response.xhr.response)
            },

        });

        image_main.on('maxfilesreached', function() {
            image_main.removeEventListeners();
        });
        image_main.on('sending', function(file, xhr, formData){
            formData.append('uid', $('.uid').val());
        });
        image_main.on('removedfile', function (file) {
            image_main.setupEventListeners();
        });

        var gallery = new Dropzone("div#gallery", {

            url: "<?php echo e(route('file.store')); ?>",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            paramName: "gallery[]",
            uploadMultiple: true,
            parallelUploads: 20,
            timeout: 180000,
            addRemoveLinks: true,
            hiddenInputContainer: ".form",
            dictRemoveFile: "Şəkli sil",
            dictCancelUpload: "Yükləməni dayandır",
            dictDefaultMessage: "Şəkli sürüşdürüb buraxın və ya Seçin",
            dictMaxFilesExceeded: "Əlavə şəkil yükləyə bilməzsiniz",

            removedfile: function(file) {
                file.previewElement.remove();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    },
                    type: 'POST',
                    url: '<?php echo e(route('files.delete')); ?>',
                    data: {'add' : 'addform', 'uid' : $('.uid').val(), 'm_image3' : file.name}
                });
                galleryitems = jQuery.grep(galleryitems, function(value) {
                    return value != file.name;
                });
                $('.m-image3').val(galleryitems);
            },

            successmultiple: function(file){
                $.each(file, function(index){
                    galleryitems = galleryitems.concat(file[index].name);
                })
                $('.m-image3').val(galleryitems);
            },

        });

        gallery.on('sending', function(file, xhr, formData){
            formData.append('uid', $('.uid').val());
        });
        gallery.on('removedfile', function (file) {
            gallery.setupEventListeners();
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/admin/project/create.blade.php ENDPATH**/ ?>