<?php $__env->startSection('title', __('titles.add').' | '.__('titles.categories')); ?>
<?php $__env->startSection('content'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('admin.add')); ?></h6>
        </div>
        <div class="card-body">
            <div class="col-md-6 offset-md-3">
                <form class="user" method="POST" action="<?php echo e(route('project-category.store')); ?>" enctype="multipart/form-data">
                    <?php echo $__env->make('admin.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                    <?php echo csrf_field(); ?>

                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <?php $__currentLoopData = Config::get('global.langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(($locale['code'] == 'en') ? 'active': ''); ?>" id="pills-tab-<?php echo e($locale['code']); ?>"
                                   data-toggle="pill" href="#pills-<?php echo e($locale['code']); ?>" role="tab"
                                   aria-controls="pills-<?php echo e($locale['code']); ?>" aria-selected="true"><?php echo e($locale['name']); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content pt-2 pl-1" id="pills-tabContent">
                        <?php $__currentLoopData = Config::get('global.langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade show <?php echo e(($locale['code'] == 'en') ? 'active': ''); ?>" id="pills-<?php echo e($locale['code']); ?>"
                                 role="tabpanel" aria-labelledby="pills-tab-<?php echo e($locale['code']); ?>">

                                <div class="form-group row">
                                    <div class="col-md-2">
                                        <label for="title"><?php echo e(__('admin.title')); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <input id="title_<?php echo e($locale['code']); ?>" type="text" class="form-control <?php $__errorArgs = ['title.'.$locale['code']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="title[<?php echo e($locale['code']); ?>]" value="<?php echo e(old('title.'.$locale['code'])); ?>"
                                               placeholder="<?php echo e(__('admin.title')); ?> (<?php echo e($locale['code']); ?>)" >
                                        <?php $__errorArgs = ['title.'.$locale['code']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-2">
                            <label for="status_id"><?php echo e(__('admin.status')); ?></label>
                        </div>
                        <div class="col-md-10">
                            <select name="status_id" id="status_id" class="form-control">
                                <option value="1" <?php echo e(selected(old('status_id'),'1')); ?>><?php echo e(__('admin.status_id_1')); ?></option>
                                <option value="0" <?php echo e(selected(old('status_id'),'0')); ?>><?php echo e(__('admin.status_id_0')); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center">

                    <button type="submit" class="btn btn-primary " id="submit_btn">
                        <?php echo e(__('admin.save')); ?>

                    </button>
                    </div>
                </form>


            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/admin/project-categories/create.blade.php ENDPATH**/ ?>