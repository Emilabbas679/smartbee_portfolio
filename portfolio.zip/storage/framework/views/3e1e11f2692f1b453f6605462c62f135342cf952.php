<script type="text/javascript" src="<?php echo e(asset('/site/js/owl.carousel.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/site/js/xate.js')); ?>"></script>

<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/site/parts/footerjs.blade.php ENDPATH**/ ?>