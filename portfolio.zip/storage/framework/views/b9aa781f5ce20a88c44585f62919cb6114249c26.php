<!-- Header start -->
<header class="header">
	<div class="x-centered">
		<div class="header-a">
			<div class="logo">
				<a href="./"></a>
			</div>
			<div class="header-right">
				<div class="hr-item hr-contact">
					<a href="./contact">Əlaqə vasitələri</a>
				</div>
				<div class="hr-item hr-language">
					<a href="#">Aze</a>
				</div>
			</div>
			<div class="top-menu">
				<ul>
					<li class="active"><a href="./">Ana səhifə</a></li>
					<li><a href="about.php">Haqqımızda</a></li>
					<li><a href="portfolio.php">Portfolio</a></li>
					<li><a href="services.php">Xidmətlər</a></li>
					<li><a href="contact.php">Əlaqə</a></li>
					<li class="prt"><a href="test">Smartbee Ads</a></li>
				</ul>
			</div>
		</div>
	</div>
</header>
<!-- Header end --><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/site/parts/header.blade.php ENDPATH**/ ?>