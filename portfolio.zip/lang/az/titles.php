<?php 
 return [
"projects" => "Layihələr",
"add" => "Əlavə et",
"categories" => "Kateqoriyalar",
"dashboard" => "Dashboard",
];