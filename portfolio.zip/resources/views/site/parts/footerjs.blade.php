<script type="text/javascript" src="{{asset('/site/js/owl.carousel.min.js')}}"></script>
<script type="text/javascript" src="{{asset('/site/js/xate.js')}}"></script>

@yield('js')
